from . import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import enum

# Define user roles as an Enum for clarity and safety
class Role(enum.Enum):
    user = "user"
    driver = "driver"

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)  # Unique user email
    name = db.Column(db.String(120))
    password_hash = db.Column(db.String(128))  # Store hashed password only
    role = db.Column(db.Enum(Role), default=Role.user)  # Default role is 'user'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Hash password before saving it to database
    def set_password(self, pw):
        self.password_hash = generate_password_hash(pw)

    # Check provided password against stored hashed password
    def check_password(self, pw):
        return check_password_hash(self.password_hash, pw)

# Additional model for ride statuses
class RideStatus(enum.Enum):
    requested = "requested"
    accepted = "accepted"
    in_progress = "in_progress"
    completed = "completed"
    cancelled = "cancelled"

class Ride(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    passenger_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    driver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    origin = db.Column(db.String(255))
    destination = db.Column(db.String(255))
    distance_km = db.Column(db.Float, default=0.0)
    price = db.Column(db.Float, default=0.0)
    status = db.Column(db.Enum(RideStatus), default=RideStatus.requested)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships to access user objects from ride
    passenger = db.relationship('User', foreign_keys=[passenger_id], backref='requested_rides')
    driver = db.relationship('User', foreign_keys=[driver_id], backref='driven_rides')
