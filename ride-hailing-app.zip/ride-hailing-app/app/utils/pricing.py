def estimate_price(distance_km: float) -> float:
    base = 30.0      # base fare in INR
    per_km = 10.0    # per km rate
    return round(base + per_km * distance_km, 2)
