# placeholder for integrating payment gateway
def process_payment(amount, payment_method):
    # In real implementation call the gateway here.
    return {'status':'success','transaction_id':'tx_mock_123'}
