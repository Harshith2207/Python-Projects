# Minimal helpers for geolocation; real apps use external services.
def mock_coords(address: str):
    # returns fake lat/lng for demo
    return {'lat': 12.9716, 'lng': 77.5946}
