from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user, login_user
from ..models import Ride, RideStatus, User
from .. import db
from ..utils.pricing import estimate_price

rides_bp = Blueprint('rides', __name__, template_folder='templates/rides')

@rides_bp.route('/request', methods=['GET','POST'])
@login_required
def request_ride():
    if request.method == 'POST':
        origin = request.form.get('origin')
        destination = request.form.get('destination')
        # simplistic distance estimate: user may provide km or we mock
        distance_km = float(request.form.get('distance_km') or 5)
        price = estimate_price(distance_km)
        ride = Ride(passenger_id=current_user.id, origin=origin, destination=destination, distance_km=distance_km, price=price)
        db.session.add(ride)
        db.session.commit()
        flash(f'Ride requested — estimated price ₹{price:.2f}', 'success')
        return redirect(url_for('rides.track_ride', ride_id=ride.id))
    return render_template('rides/request.html')

@rides_bp.route('/<int:ride_id>/track')
@login_required
def track_ride(ride_id):
    ride = Ride.query.get_or_404(ride_id)
    return render_template('rides/track.html', ride=ride)

@rides_bp.route('/history')
@login_required
def history():
    rides = Ride.query.filter_by(passenger_id=current_user.id).order_by(Ride.created_at.desc()).all()
    return render_template('rides/history.html', rides=rides)

# simple API to let a developer mark ride accepted (mock)
@rides_bp.route('/<int:ride_id>/accept', methods=['POST'])
def accept(ride_id):
    ride = Ride.query.get_or_404(ride_id)
    ride.status = RideStatus.accepted
    # assign a dummy driver if none
    driver = User.query.filter_by(role='driver').first()
    if driver:
        ride.driver_id = driver.id
    db.session.commit()
    return jsonify({'status':'accepted','ride_id':ride.id})
