from flask import Blueprint, render_template, redirect, url_for, flash, request
from ..models import User
from .. import db
from flask_login import login_user, logout_user, login_required, current_user

auth_bp = Blueprint('auth', __name__, template_folder='templates', url_prefix='/auth')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    # Handle POST form submission for user registration
    if request.method == 'POST':
        email = request.form.get('email')
        name = request.form.get('name')
        password = request.form.get('password')

        # Check if email already registered to avoid duplicates
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'warning')
            return redirect(url_for('auth.register'))

        # Create new user instance and hash the password securely
        user = User(email=email, name=name)
        user.set_password(password)

        # Add and commit new user to the database
        db.session.add(user)
        db.session.commit()

        flash('Registration successful. Please login.', 'success')
        return redirect(url_for('auth.login'))

    # Render registration page for GET request
    return render_template('auth/register.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    # Handle POST form submission for login
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Find user by email
        user = User.query.filter_by(email=email).first()

        # Validate user existence and password correctness
        if not user or not user.check_password(password):
            flash('Invalid credentials', 'danger')
            return redirect(url_for('auth.login'))

        # Log the user in and redirect to the main index page
        login_user(user)
        return redirect(url_for('main.index'))

    # Render login page for GET request
    return render_template('auth/login.html')

@auth_bp.route('/logout')
@login_required  # Only logged-in users can logout
def logout():
    logout_user()
    flash('Logged out successfully.', 'info')
    return redirect(url_for('main.index'))
