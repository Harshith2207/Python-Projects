from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from ..models import Ride
from .. import db

payments_bp = Blueprint('payments', __name__, template_folder='templates/payments')

@payments_bp.route('/checkout/<int:ride_id>', methods=['GET','POST'])
@login_required
def checkout(ride_id):
    ride = Ride.query.get_or_404(ride_id)
    if request.method == 'POST':
        # mock payment processing
        flash('Payment successful (mock). Ride confirmed!', 'success')
        ride.status = ride.status  # in real app, update status when driver accepts
        db.session.commit()
        return redirect(url_for('rides.track_ride', ride_id=ride.id))
    return render_template('payments/checkout.html', ride=ride)

@payments_bp.route('/history')
@login_required
def history():
    # placeholder
    return render_template('payments/history.html')
