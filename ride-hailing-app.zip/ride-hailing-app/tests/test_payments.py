def test_payment_mock():
    from app.utils.payments import process_payment
    res = process_payment(100, 'card')
    assert res['status'] == 'success'
