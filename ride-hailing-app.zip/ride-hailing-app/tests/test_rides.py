def test_estimate():
    from app.utils.pricing import estimate_price
    assert estimate_price(5) == 30 + 10*5
