# PokéPrint Rapido/Uber-like Hackathon App

Simple Flask-based prototype for a ride-hailing app (demo).
Structure provided by the user; this repository contains:
- Flask backend (SQLite)
- Basic auth with Flask-Login (email/password)
- Ride request flow (request -> mock accept -> track)
- Simple pricing utility and mock payments
- Templates + static assets (very small)
- Tests (pytest)

Run:
1. python3 -m venv venv
2. source venv/bin/activate    # or `venv\Scripts\activate` on Windows
3. pip install -r requirements.txt
4. export FLASK_APP=run.py
5. flask db upgrade   # creates sqlite database
6. flask run

This is a minimal prototype suitable for hackathon demos and extension.
